import React from 'react'
import './Hero.css'

const Hero = () => {
  return (
    <div className="hero">
        <div className="hero-text">
            <h2>Welcome</h2>
            <h1>We serve the richest coffee in the city. </h1>
            <button className="order-now">Order Now</button>
        </div>
    </div>
  )
}

export default Hero