import React, {useRef} from 'react'
import './Programs.css'
import next_icon from '../assets/next-icon.png'
import back_icon from '../assets/back-icon.png'
import americano from '../assets/americano.jpeg'
import cortado from '../assets/cortado.jpg'
import dalgona from '../assets/dalgona.jpeg'
import filter from '../assets/filter.jpg'
import icedcoffee from '../assets/icedcoffee.jpeg'
import latte from '../assets/latte.jpeg'
import lungo from '../assets/lungocoffee.jpeg'
import macchito from '../assets/macchito.jpeg'


const Programs = () => {
  
    const slider = useRef();
    let tx = 0;
  
    const slideForward = () => {
        if(tx > -100){
            tx -= 50;
        }
        slider.current.style.transform = `translateX(${tx}%)`;
    }

    const slideBackward = () => {
        if(tx < 0){
            tx += 50;
        }
        slider.current.style.transform = `translateX(${tx}%)`;
    }
  
  
    return (
    <div className="coffee">
        <img src={next_icon} className="next-btn" alt="next_btn" onClick={slideForward} />
        <img src={back_icon} className="back-btn" alt="back-btn" onClick = {slideBackward}/>
        <div className="slider">
            <ul ref={slider}> 
                <li>
                    <div className="slide">
                        <div className="coffee-info">
                            <img src={americano} alt="americano" />
                            <div>
                                <h3>Americano</h3>
                                <span>Less concentrated shot of espresso.</span>
                                <h3>Rs.150</h3>
                                <button className="order-btn">Order Now</button>
                            </div>
                        </div>
                    </div>
                </li>
                <li>
                    <div className="slide">
                        <div className="coffee-info">
                            <img src={cortado} alt="cortado coffee" />
                            <div>
                                <h3>Cortado Coffee</h3>
                                <span>Less concentrated shot of espresso.</span>
                                <h3>Rs.200</h3>
                                <button className="order-btn">Order Now</button>
                            </div>
                        </div>
                    </div>
                </li>
                <li>
                    <div className="slide">
                        <div className="coffee-info">
                            <img src={dalgona} alt="dalgona coffee" />
                            <div>
                                <h3>Dalgona Coffee</h3>
                                <span>Less concentrated shot of espresso.</span>
                                <h3>Rs.199</h3>
                                <button className="order-btn">Order Now</button>
                            </div>
                        </div>
                    </div>
                </li>
                <li>
                    <div className="slide">
                        <div className="coffee-info">
                            <img src={filter} alt="Filtered coffee" />
                            <div>
                                <h3>Filtered Coffee</h3>
                                <span>Less concentrated shot of espresso.</span>
                                <h3>Rs.199</h3>
                                <button className="order-btn">Order Now</button>
                            </div>
                        </div>
                    </div>
                </li>
                <li>
                    <div className="slide">
                        <div className="coffee-info">
                            <img src={icedcoffee} alt="Iced coffee" />
                            <div>
                                <h3>Iced Coffee</h3>
                                <span>Less concentrated shot of espresso.</span>
                                <h3>Rs.199</h3>
                                <button className="order-btn">Order Now</button>
                            </div>
                        </div>
                    </div>
                </li>
                <li>
                    <div className="slide">
                        <div className="coffee-info">
                            <img src={latte} alt="latte" />
                            <div>
                                <h3>Latte</h3>
                                <span>Less concentrated shot of espresso.</span>
                                <h3>Rs.199</h3>
                                <button className="order-btn">Order Now</button>
                            </div>
                        </div>
                    </div>
                </li>
                <li>
                    <div className="slide">
                        <div className="coffee-info">
                            <img src={lungo} alt="lungo" />
                            <div>
                                <h3>Lungo</h3>
                                <span>Less concentrated shot of espresso.</span>
                                <h3>Rs.199</h3>
                                <button className="order-btn">Order Now</button>
                            </div>
                        </div>
                    </div>
                </li>
                <li>
                    <div className="slide">
                        <div className="coffee-info">
                            <img src={macchito} alt="macchito" />
                            <div>
                                <h3>Macchito</h3>
                                <span>Less concentrated shot of espresso.</span>
                                <h3>Rs.199</h3>
                                <button className="order-btn">Order Now</button>
                            </div>
                        </div>
                    </div>
                </li>
            </ul>
        </div>
    </div>
  )
}

export default Programs