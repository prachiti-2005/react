import React, {useState, useEffect} from 'react';
import './Navbar.css'
import logo from '../assets/icon.png'
import login from '../assets/login.png'

const Navbar = () => {
  
    const [sticky, setSticky] = useState(false);
  
    useEffect(() => {
        const handleScroll = () => {
          setSticky(window.scrollY > 50);
        };
    
        window.addEventListener('scroll', handleScroll);
        return () => {
          window.removeEventListener('scroll', handleScroll);
        };
      }, []);
  
  
    return (
    <nav className={`container ${sticky ? 'dark-nav' : ''}`}> 
        <img src={logo} alt="coffee-logo" className="logo" />
       <ul>
        <li><a href="#">Home</a></li>
        <li><a href="#">Coffee</a></li>
        <li><a href="#">Bakery</a></li>
        <li><a href="#">About</a></li>
        <li><button className="btn">Login <img src={login} alt="login btn" /></button></li>
       </ul>
    </nav>


);
}

export default Navbar