import React from 'react'
import Navbar from './Navbar/Navbar.jsx'
import Hero from './Hero/Hero.jsx'
import Title from './Title/Title.jsx'
import Program from './Programs/Programs.jsx'

const App = () => {
  return (
    <div>
        <Navbar/>
        <Hero/>
        <div className="container">
          <Title title = "OUR SPECIAL COFFEE" />
          <Program/>
        </div>
    </div>
  )
}

export default App