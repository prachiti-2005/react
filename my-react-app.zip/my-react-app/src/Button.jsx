/* External Styling */
/*import styles from './Button.module.css'
function Button(){
    return (
        <button className={styles.button}>Click Me</button>

    );
}*/

/*Inline Styling */ 
/*function Button(){

    const styles={

        backgroundColor: "hsl(200, 100%, 50%)",
        color:"white",
        padding:"10px 20px",
        borderRadius: "5px",
        border: "none",
        cursor: "pointer",
    }

    return (
        <button className={styles}>Click Me</button>

    );
}*/


// Click event = AN interaction when a user clicks on a button 
// Event handler = a function that handles the event

function Button(){
    /*let count = 0;
    const handleClick = (name) => {
       if(count < 3){
        count++;
        console.log(`${name}You clicked me  ${count} times/s`);
       } 
       else{
        console.log(`${name} stop clicking me `);
       }
    };  */

    const handleClick = (e) => e.target.textContent = "OUCH!";
        
    
    
    return(

        <button onDoubleClick={(e) => handleClick(e)}>Click Me</button>

    );
}
export default Button




