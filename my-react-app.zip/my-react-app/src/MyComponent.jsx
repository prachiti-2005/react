/* React hook = special function that allows functional components to
use react features without writing class components (react v16.8)
(useState, useEffect, etc)....

useState() = a react hook that allows the creation of a stateful variable and a setter 
function to update its value in the virtual DOM [name, setName]*/


/*function MyComponent(){
    const [name, setName] = useState("guest");
    const [age, setAge] = useState(0);
    const [isEmployed, setIsEmployed] = useState(false);
    const updateName = () => {
       setName("SpongeBob");
    }

    const incrementAge = () => {
        setAge(age + 1);
    }

    const toggleEmployedStatus = () =>{
        setIsEmployed(!isEmployed);


    }

    return(
        <div>
            <p>Name : {name}</p>
            <button onClick = {updateName}>Set Name</button>
            
            <p>Age : {age}</p>
            <button onClick = {incrementAge}>Increment Age</button>

            <p>Is employed : {isEmployed ? "Yes" : "NO"}</p>
            <button onClick ={toggleEmployedStatus}>Employment toggle </button>


        </div>


    );



}*/


/*onChange = event handler used for primarily with form elements
ex <input>, <textarea>, <select>, <radio>
triggers a function every time the value of the input changes */


/*function MyComponent(){

    const [name, setName] = useState("Guest");
    const[quantity, setQuantity] = useState(1);
    const [comment, setComment]=useState("");
    const [payment, setPayment] = useState("");
    const [shipping, setShipping] = useState("Delivery");


    function handleNameChange(event){
        setName(event.target.value);
    }

    function handleQuantityChange(event){
        setQuantity(event.target.value);
    }

    function handleCommentChange(event){
        setComment(event.target.value);
    }

    function handlePaymentChange(event){
        setPayment(event.target.value);
    }

    function handleShippingChange(event){
        setShipping(event.target.value);
    }

    return(
    <>
    <div>
        <input value ={name} onChange={handleNameChange}/>
        <p>Name: {name}</p>

        <input value = {quantity} onChange={handleQuantityChange} type="number"/>
        <p>Quantity :{quantity}</p>

        <textarea value={comment} onChange={handleCommentChange} 
        placeholder="Enter delivery instructions "/>
        <p>Comment : {comment}</p>

        <select value={payment} onChange={handlePaymentChange}> 
            <option value="">Select an option</option>
            <option value="visa">Visa</option>
            <option value="Mastercard">Mastercard</option>
            <option value="GiftCard">Giftcard</option>

        </select>
        <p>Payment : {payment}</p>

        <label>
            <input type="radio" value="Pickup"
                checked={shipping === "Pickup"}
                onChange ={handleShippingChange}
                />
            PickUp
        </label><br/>
        <label >
        <input type="radio" value="Delivery"
                checked={shipping === "Delivery"}
                onChange ={handleShippingChange}
                />
            Delivery
        </label>
        <p>Shipping :{shipping}</p>
    </div>
    

    
    </>);
}*/

/*updater function : a function passed as an argument to setState() usually
ex. setYear(updater function)
 Allow for safe updates based on the previous state
used with multiple state updates and asynchronous function  */


/*function MyComponent(){
    const [count, setCount] = useState(0);
    // takes the pending state to calculate next state
    // react puts your updater function in a queue
    // during the next render, it will call them in same order


    const increment = () =>{
        setCount(c => c + 1);
    }

    const decrement = () => {
        setCount(c => c - 1);
        

    }

    const reset = () =>{
        setCount(0 );
    }

    return(
        <div className = "counter-container">
            <p className = "count-display">Count : {count}</p>
            <button className = "counter-button" onClick={decrement}>Decrement</button>
            <button className = "counter-button" onClick={reset}>Reset</button>
            <button className = "counter-button" onClick={increment}>Increment</button>
        </div>
    );
}*/
// update objects in stats
/*function MyComponent(){
    const [car,setCar]=useState({year:"2024",
                                make:"Ford", 
                                model:"Mustang"});

    function handleYearChange(event){
        setCar(c => ({...c, year:event.target.value})); //... spread operator
        
    
    }

    function handleMakeChange(event){
        setCar(c => ({...c, make:event.target.value})); //... spread operator

    }

    function handleModelChange(event){
        setCar(c => ({...c, model:event.target.value})); //... spread operator

    }
    
    return(
        <div>
            <p>Your favorite car is : {car.year} {car.make } {car.model}</p>
            <input type="number" value={car.year} onChange={handleYearChange}/><br/>
            <input type="text" value={car.make} onChange={handleMakeChange}/><br/>
            <input type="text" value={car.model} onChange={handleModelChange}/><br/>

        </div>



    );
}*/

//update arrays in state

/*function MyComponent(){

    const [foods, setFoods] = useState(["Apple", "Orange", "Banana"]); 
    
    function handleAddFood(){
        const newFood = document.getElementById("foodInput").value;
        document.getElementById("foodInput").value="";

        setFoods([...food, newFood]);
    }   

    function handleRemoveFood(index){
        setFoods(foods.filter((_, i) => i !== index));
    }


    return(

        <div>
            <h2>List of Food</h2>
            <ul>
                {foods.map((food, index) => <li key={index} onClick={()=>handleRemoveFood}>{food}</li>)}
            </ul>
            <input type="text" id="foodInput" placeholder="Enter food name"/>
            <button onClick={handleAddFood}>Add Food </button>
        </div>


    );
}*/


/*function MyComponent() {
    const [cars, setCars] = useState([]);
    const [carYear, setCarYear] = useState(new Date().getFullYear());
    const [carMake, setCarMake] = useState("");
    const [carModel, setCarModel] = useState("");

    function handleAddCar() {
       const newCar = {year:carYear, make:carMake, model:carModel};
        setCars(c => [...c,newCar]);

        setCarYear(new Date().getFullYear());
        setCarMake("");
        setCarModel("");
    }

    function handleRemoveCar(index) {
        setCars(c => c.filter((_, i) => i !== index));
    }

    function handleYearChange(event) {
        setCarYear(event.target.value);
    }

    function handleMakeChange(event) {
        setCarMake(event.target.value);
    }

    function handleModelChange(event) {
        setCarModel(event.target.value);
    }

    return (
        <div>
            <h2>List of Car Objects</h2>
            <ul>
                {cars.map((car, index) => 
                    <li key={index} onClick={()=>handleRemoveCar(index)}>
                        {car.year} {car.make} {car.model}
                    </li>
                    )}
            </ul>

            <input type="number" value={carYear} onChange={handleYearChange} /><br />
            <input type="text" value={carMake} onChange={handleMakeChange} placeholder="Enter Car make" /><br />
            <input type="text" value={carModel} onChange={handleModelChange} placeholder="Enter Car model" /><br />
            <button onClick={handleAddCar}>Add Car</button>
        </div>
    );
}*/
/*useEffect() = React hook tells react to do same code when (pick one)
this component re-renders
this component mounds
the state of the value

useEffect(function, [dependencies])

1.useEffect(()=>{})  //Runs after every re render
2.useEffect() => {},[]) // Runs only on mount
3.useEffect(() => {} ,[value]) // Runs on mount+when value changes

// Uses
Event listners
dom manipulation
subscriptions 
fetching data from apis 
clean up when a component unmount
*/

/*function MyComponent() {
  const [count, setCount] = useState(0);
  const [color, setColor] = useState("green");

  useEffect(() => {
    document.title = `Count : ${count} ${color}`;

  }, [count, color]);

  function addCount() {
    setCount(c => c + 1);
  }

  function subtractCount() {
    setCount(c => c - 1);
  }

  function changeColor() {
    setColor(c => (c === "green" ? "red" : "green"));
  }

  return (
    <>
      <p style={{ color: color }}>Count: {count}</p>
      <button onClick={addCount}>Add</button>
      <button onClick={subtractCount}>Subtract</button><br />
      <button onClick={changeColor}>Change Color</button> 
    </>
  );
}*/


/*const MyComponent = () => {
  
    const [width, setWidth] = useState(window.innerWidth);
    const [height, setHeight] = useState(window.innerHeight);

    /*without useEffect()
    window.addEventListener("resize", handleResize);
    console.log("Event listener added");*/

   /* useEffect(() =>{
        window.addEventListener("resize", handleResize);
        console.log("Event listener added");

        return ()=>{
            window.removeEventListener("resize", handleResize);
            console.log("Event listener removed");
        } 

    }, [] );

    function handleResize(){
        setWidth(window.innerWidth);
        setHeight(window.innerHeight);
    }

    return(
        <>
        <p>Window Width : {width} px </p>
        <p>Window Height : {height} px</p>
        </>
    );
}*/

// useRef()

import React, { useState, useEffect, useRef } from 'react';

function MyComponent() {
    
    //const ref = useRef(0); //returns the object 
    
    const inputRef = useRef(null);
    
    useEffect(() => {
        console.log("Component Rendered");
        console.log(inputRef);
    });
    
    
    function handleClick(){
        inputRef.current.focus();
    }
  
  
    return(
        <div>
        <button onClick={handleClick}>
            Click me
        </button>
        <input ref={inputRef}/>
        </div>
    );
}

export default MyComponent





