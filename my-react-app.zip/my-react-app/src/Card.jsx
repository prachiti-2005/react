import profilePic from './assets/profile.png'
function Card(){

    return(
        <div className = "card">
            <img className="image" src={profilePic} alt="profile picture"></img>
            <h2 className = "card-title">Prachiti Phadke </h2>
            <p className="card-text">I am a student and I like playing games</p>


        </div>


    );
}

export default Card