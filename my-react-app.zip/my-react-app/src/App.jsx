/*import Header from './Header.jsx'
import Footer from './Footer.jsx'
import Food from './Food.jsx'
function App() {
  return(
    <>
      <Header></Header>
      <Food></Food>
      <Footer></Footer>

    </>
  );
}*/



/* Card Component 

import Card from './Card.jsx'

function App(){
  return(
    <>
    <Card/> 
    <Card/>
    </>
  );

}*/

/* hOW TO STYLE REACT component with css

1.External - global for small projects
2.Modules - individual components
3.Inline - small components with minimal styling 

import Button from './Button.jsx'
function App(){
  return(
    <Button></Button>
  );
}
*/

/* props = read only properties that are shared between components
          A parent component can send data to a child component
          <Component key = value />
*/
/*import Student from './Student.jsx'
function App(){
  return (
  <>
    <Student name="Spongebob" age={30} isStudent={true}/>
    <Student name="Patrick" age={42} isStudent={false}/>
    <Student name = "Squidward" age ={50} isStudent={false} />
    <Student name="Sandy" age={27} isStudent = {true} />
    <Student name="Larry"/>
  </>
  );
}*/

/*conditional rendering : allows you to control what gets rendered 
                          in your application based on certain conditions
                          (show hide or change components) */

/*import UserGreetings from "./UserGreetings.jsx";

function App() {
  return (
    <UserGreetings isLoggedIn={true} username="prachiti" />
  );
}*/

/*List rendering */

/*import List from './List.jsx'
function App(){
  const fruits = [{id:6,name:"potatoes", calories:110},
    {id:7,name:"celery", calories:15},
    {id:8,name:"carrots", calories:25},
    {id:9,name:"corn", calories :63},
    {id:10,name:"broccoli", calories:50}];

    const vegetables = [{id:6,name:"potatoes", calories:110},
      {id:7,name:"celery", calories:15},
      {id:8,name:"carrots", calories:25},
      {id:9,name:"corn", calories :63},
      {id:10,name:"broccoli", calories:50}];
  
    return(
      <>
    {fruits.length > 0 && <List items = {fruits} category ="fruits"/> }
    {vegetables.length > 0 ? <List items = {vegetables} category = "vegetables "/> : null}
    </>
  );
}*/

// Click 
/*import Button from './Button.jsx'

  function App(){
    return(
      <Button/>


    );
  }*/

  /*import ProfilePicture from "./ProfilePicture.jsx"
  function App(){
    return(
      <ProfilePicture/>

    );
  } */
// React Hook 
    /*import MyComponent from './MyComponent.jsx'
  function App(){
    return(
      <MyComponent/>
    );
  }*/

// Counter program 
/*import Counter from './Counter.jsx';

function App() {
  return (
    <Counter />
  );
}*/
/*onchange event handler 
import MyComponent  from "./MyComponent.jsx";

function App(){
  return(
  <MyComponent/>
  );
}*/

/*import ColorPicker from './ColorPicker.jsx'
function App(){
  return(
    <ColorPicker/>


  );
}*/

/*Updater function*/

/*import MyComponent  from "./MyComponent.jsx";
function App(){
  return(
    <MyComponent/>
  );
}*/
/*import ToDoList from "./ToDoList.jsx";
function App(){
  return(
    <ToDoList/>
  );
}*/

/*import MyComponent from './MyComponent.jsx'
// useEffect()
const App = () => {
  return (
    <MyComponent/>
  );
}*/
// useContextHook() 

//useRef 
/*import MyComponent from './MyComponent.jsx'

const App = () => {
  return (
    <MyComponent/>
  );
}

export default App*/


import React from 'react'

const App = () => {
  return (
    <div className="text-3xl text-blue-500 font-bold underline">
      Hello, Tailwind in React!
    </div>
  );
}

export default App
