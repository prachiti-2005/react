
function footer(){
    return(
        <footer>
            <p>&copy;{new Date().getFullYear()} Your Website Name</p>

        </footer>
    );

}

export default footer